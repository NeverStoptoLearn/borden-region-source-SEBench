# Borden Inverse Judge Feedback Policy

This task uses a DAG-style process judge.

1. `FINAL_SCORE` / structured `score`
   - Strict process score after soft dependency caps and any optional run-time
     progress cap.
   - This is the authoritative score for ranking.

2. `LEARNING_SCORE` / `visible_learning_score` / `raw_total_score`
   - Continuous raw process score before soft end-to-end and time caps.
   - This is exposed so agents can see whether a candidate improved even when
     the strict score is limited.

The judge still evaluates hidden monitoring and future-time predictions with the
private ADE region-source reference model. However, ADE correctness is now an
upstream dependency quality signal, not a hard switch that zeroes all later
components. Later source-answer components receive isolated credit using the
judge reference model; native/end-to-end credit is reduced continuously when the
submitted `forward_model.py` is weak.

## Scoring Sequence

1. Static `forward_model.py` relevance/safety check.
2. Dynamic public ADE correctness probe. The reference threshold remains
   `ADE_CORRECTNESS_SCORE >= 7.5 / 10`, but missing the threshold no longer
   clears hidden/future/physics process credit.
3. Source-answer scoring with the private reference model.
4. Soft dependency aggregation:
   - local upstream score: schema, static model relevance, ADE probe quality,
     workflow/reporting;
   - isolated downstream score: public fit, hidden fit, future fit, source
     physics;
   - native downstream score: isolated downstream score multiplied by a soft
     function of model/ADE quality;
   - strict score: raw process score after soft end-to-end and optional time
     caps.

The structured result exposes coarse bands, component scores, and teacher-style
hints. It does not expose hidden observations, true source parameters, exact
pointwise hidden residuals, or hidden well identities beyond coarse aggregate
labels.

## Structured Feedback Fields

- `final_score` / `strict_score`: strict process score after caps.
- `visible_learning_score` / `learning_score` / `raw_total_score`: raw process
  score before soft caps.
- `process_scores`: local, isolated, native, dependency multiplier, soft cap,
  and optional time-cap diagnostics.
- `cap_delta`: `visible_learning_score - final_score`.
- `cap_reason`: currently active structural, soft end-to-end, or time cap.
- `ade_correctness_gate_status`: `passed`, `failed`, or `not_run`; this is a
  diagnostic threshold, not a zeroing rule.
- `ade_correctness_score`: 0-10 dynamic public ADE probe score.
- `ade_probe_band`, `ade_probe_component`, and `ade_probe_feedback`: coarse
  public probe feedback for the forward model.
- `post_ade_components_zeroed`: retained for backward compatibility and normally
  `false` under this policy.
- `metric_bands`: coarse hidden/future quality bands.
- `component_scores` and `component_progress`: decomposed process feedback.
- `weakest_component` and `next_hint`: the main next action.
- `model_feedback`, `ade_feedback`, and `physical_feedback`: static/gate issues
  when available.

## Hint Semantics

If the submitted ADE model gate fails, the hint points to `forward_model.py`, but
the judge still reports isolated source-answer progress when `answer.json` is
usable.

If the static gate passes but the public ADE probe is weak, the hint points to
ADE response mismatch, especially source normalization, finite release timing,
advection velocity, anisotropic dispersion, and rectangular-region
superposition.

If hidden/future prediction is weak while source physics is improving, the hint
will point back to plume timing or downstream fit. If source geometry is weak
while predictions are plausible, the hint points to physical consistency.

## Rationale

This matches multi-part problem grading: an incorrect upstream step limits the
fully chained answer, but the judge can still decide whether later work is
methodologically correct by evaluating it with controlled reference inputs. The
result is a smoother learning slope without making the task trivial.
